bugs.txt --> rundown of bugs and which test cases cause the binaries to fail

changes.txt --> revision 10/28 due to bugs

MAKE SURE TO CHANGE PATHS IN bftpd.conf!!!
