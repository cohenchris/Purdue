#!/bin/bash
echo Hello there people! > outfile.txt
cat < outfile.txt
